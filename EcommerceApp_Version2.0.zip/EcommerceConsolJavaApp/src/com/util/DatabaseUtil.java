package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
	private static Connection connection;

	public static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/shopping_cart";
	public static final String DB_USERNAME = "root";
	public static final String DB_PASSWORD = "pass@word1";

	public DatabaseUtil() {

	}

	// Method to create connection to DB
	public void createConnection() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Method to get the resultset from DB
	public ResultSet getResultSet(String query) {
		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet resultSet;
			resultSet = statement.executeQuery(query);
			return resultSet;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
		return null;

	}

	// Method to close the connection
	public static void closeConnection() {
		try {
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			System.out.println("Error in closing database connection" + e.getMessage());

		}
	}

	public static void printResultSet(ResultSet resultSet) {
		try {
			while (resultSet.next()) {
				for (int i = 1; i <= resultSet.getMetaData().getColumnCount(); i++) {
					System.out.print(resultSet.getObject(i) + " | ");
				}
				System.out.println();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
	}

	// Method to run the query in DB
	public void executeDBQuery(String query) {
		PreparedStatement ps;
		try {
			ps = connection.prepareStatement(query);
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		closeConnection();
	}

}
