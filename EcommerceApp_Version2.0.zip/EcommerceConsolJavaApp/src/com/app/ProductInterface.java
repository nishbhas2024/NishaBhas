package com.app;

public interface ProductInterface {

	int getProduct_id();

	void setProduct_id(int product_id);

	String getProduct_name();

	void setProduct_name(String product_name);

	String getProduct_category();

	void setProduct_category(String product_category);

	double getPrice();

	void setPrice(double price);

	int getAvailableQuantity();

	void setAvailableQuantity(int quantity);

}
