package com.data;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.app.Product;
import com.util.DatabaseUtil;

public class Inventory implements InventoryInterface {

	static List<Product> products;
	DatabaseUtil db = new DatabaseUtil();

	// constructor
	public Inventory() {
		super();
		getProductsFromDB();
	}

	@Override
	public List<Product> getProducts() {
		return products;
	}

	@Override
	public void setProducts(List<Product> products) {
		this.products = products;
	}

	// Method to get the Products data from DB
	public List<Product> getProductsFromDB() {

		int product_id;
		String product_name;
		String product_category;
		double price;
		int availableQuantity;
		products = new ArrayList<>();

		try {

			db.createConnection();
			String query = "select* from product";
			ResultSet resultSet = db.getResultSet(query);

			while (resultSet.next()) {

				product_id = resultSet.getInt("product_id");
				product_category = resultSet.getString("product_category").trim();
				product_name = resultSet.getString("product_name").trim();
				price = resultSet.getDouble("product_price");
				availableQuantity = resultSet.getInt("product_availability");
				this.products.add(new Product(product_id, product_category, product_name, price, availableQuantity));

			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return products;
	}

	// Method to add a product to DB
	@Override
	public Inventory addProduct(int product_id, String product_category, String product_name, double price,
			int availableQuantity) {
		double product_total = 0;
		String query = " insert into product values(" + product_id + ",'" + product_category + "','" + product_name
				+ "'," + price + "," + availableQuantity + "," + product_total + ")";
		db.executeDBQuery(query);
		return new Inventory();

	}

	// Method to remove any product from DB using the product ID
	@Override
	public Inventory removeProduct(int product_id) {

		String query = "delete from product where  product_id in (" + product_id + ")";
		db.executeDBQuery(query);
		return new Inventory();

	}

	// Main method to test the Inventory class... created for testing purpose...
	/*
	 * public static void main(String[] args) throws Exception { Inventory inv = new
	 * Inventory(); inv.addProduct(9, "Vehicle", "Bike", 2500.00, 5);
	 * 
	 * System.out.printf("| %11s | %-20s | %-20s | %-15s | %19s |\n", "Product ID",
	 * "Product Category", "Product Name", "Product Price", "Available Quantity");
	 * 
	 * System.out.println(
	 * "----------------------------------------------------------------------------------------------------"
	 * ); try { for (Product prod : products) {
	 * 
	 * System.out.printf("| %-11d | %-20s | %-20s | %-15.2f | %19d |\n",
	 * prod.getProduct_id(), prod.getProduct_category(), prod.getProduct_name(),
	 * prod.getPrice(), prod.getAvailableQuantity()); System.out.println(
	 * "----------------------------------------------------------------------------------------------------"
	 * );
	 * 
	 * }
	 * 
	 * } catch (Exception e) {
	 * 
	 * e.printStackTrace(); } inv.removeProduct(9);
	 * 
	 * System.out.println("\n\n************");
	 * 
	 * System.out.printf("| %11s | %-20s | %-20s | %-15s | %19s |\n", "Product ID",
	 * "Product Category", "Product Name", "Product Price", "Available Quantity");
	 * 
	 * System.out.println(
	 * "----------------------------------------------------------------------------------------------------"
	 * ); try { for (Product prod : products) {
	 * 
	 * System.out.printf("| %-11d | %-20s | %-20s | %-15.2f | %19d |\n",
	 * prod.getProduct_id(), prod.getProduct_category(), prod.getProduct_name(),
	 * prod.getPrice(), prod.getAvailableQuantity()); System.out.println(
	 * "----------------------------------------------------------------------------------------------------"
	 * );
	 * 
	 * }
	 * 
	 * } catch (Exception e) {
	 * 
	 * e.printStackTrace(); }
	 * 
	 * }
	 */
}
