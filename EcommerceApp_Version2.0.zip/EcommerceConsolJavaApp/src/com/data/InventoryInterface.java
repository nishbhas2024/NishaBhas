package com.data;

import java.util.List;

import com.app.Product;

public interface InventoryInterface {

	List<Product> getProducts();

	void setProducts(List<Product> lproducts);

	Inventory addProduct(int product_id, String product_category, String product_name, double price,
			int availableQuantity);

	Inventory removeProduct(int product_id);
}
