package com.service;

import java.util.ArrayList;
import java.util.List;

import com.app.Product;
import com.data.Inventory;

public class OrderDetails {
	private List<Integer> quantities;
	private List<Product> products;

	Inventory inv = new Inventory();
	ShoppingCart scart = new ShoppingCart();

	public OrderDetails() {
		super();
		this.quantities = new ArrayList<>();
		this.products = new ArrayList<>();
	}

	public List<Integer> getQuantities() {
		return quantities;
	}

	public void setQuantities(List<Integer> quantities) {
		this.quantities = quantities;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public void addProduct(Product product, int quantity) {
		products.add(product);
		quantities.add(quantity);
	}

	// Method to display the Order Details.
	public void displayOrderDetails(Inventory inventory, ShoppingCart scart) {
		if (!getProducts().isEmpty()) {
			System.out.println("\n***********Order Details***********");
			double totalCost = 0;
			System.out.printf("| %-9s | %11s | %-20s | %-20s | %-9s | %-15s | %-10s |\n", "S.No", "Product ID",
					"Product Category", "Product Name", "Quantity", "Product Price", "Cost");
			System.out.println(
					"-------------------------------------------------------------------------------------------------------------------");
			for (int i = 0; i < products.size(); i++) {
				Product product = products.get(i);
				int quantity = quantities.get(i);
				double cost = product.getPrice() * quantity;

				System.out.printf("| %-9d | %-11d | %-20s | %-20s | %-9d | %-15.2f | %10.2f |\n", (i + 1),
						product.getProduct_id(), product.getProduct_category(), product.getProduct_name(), quantity,
						product.getPrice(), cost);
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------");
				totalCost += cost;

			}
			System.out.println("Total Cost: " + totalCost);
			System.out.println(
					"-------------------------------------------------------------------------------------------------------------------");

		} else {
			System.out.println("\n***No orders found***");
		}
	}

}
