package com.service;

import java.util.ArrayList;
import java.util.List;

import com.app.Product;
import com.data.Inventory;

public class ShoppingCart {

	private List<Integer> quantities;
	private List<Product> products;
	Inventory inv = new Inventory();

	// constructor
	public ShoppingCart() {
		super();
		this.quantities = new ArrayList<>();
		this.products = new ArrayList<>();
	}

	public List<Integer> getquantities() {
		return quantities;
	}

	public void setQuantity(List<Integer> quantities) {
		this.quantities = quantities;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	// Method to add the product to Cart
	public void addProduct(Product product, int quantity) {
		products.add(product);
		quantities.add(quantity);
	}

	// Method to remove the product from Cart
	public void removeProduct(int product_id) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getProduct_id() == (product_id)) {
				products.remove(i);
				quantities.remove(i);

			}
		}
	}

	// Method to update the product quantity in Cart
	public void updateProductQuantityInCart(int product_id, int quantity) {
		for (int i = 0; i < products.size(); i++) {
			if (products.get(i).getProduct_id() == (product_id)) {
				quantities.set(i, quantity);
			}
		}
	}

	// Method to get the product quantity from Cart
	public int getProductQuantityFromCart(int product_id) {
		for (int i = 0; i < this.products.size(); i++) {
			if (products.get(i).getProduct_id() == (product_id)) {
				return quantities.get(i);
			}
		}
		return 0;
	}

	// Method to set the product quantity in Cart
	public void setProductQuantitytoCart(int product_id, int quantity) {
		for (int i = 0; i < this.products.size(); i++) {
			if (products.get(i).getProduct_id() == (product_id)) {
				quantities.set(i, quantity);
			}
		}

	}

}
